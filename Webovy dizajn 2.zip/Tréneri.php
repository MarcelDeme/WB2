<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Tréneri</title>

</head>
<body>
<?php include "hlavičkapeta/header.php";?>  



    <div id="Tréneri">
    <h2>Samuel Deme
    <p>0908 658 889</p>
    <p>judosamodem@gmail.com</p>
    <p> Tono Muller<p>
    <p>0915 654 658<p>
    <p>tondomuller@gmail.com</p></h2>
    </div>

    
<?php include "hlavičkapeta/footer.php"; ?>

</body>
</html>