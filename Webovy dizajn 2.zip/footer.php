<footer>
    <!DOCTYPE html>
    <html lang="sk">
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" type="text/css" href="style.css">
            <title>Kontakt</title>
        </head>
        <body>
            <main>
                <div id="footer">
                    <section>
                        <h3>Kontakt</h3>
                        <div id="rs-basketbal">   
                        <h3>RS-basketbal</h3>
                        <p>Tulipánova 1841/19</p>
                        <p>979 01 Rimavská Sobota</p>
                        </div>
                        <div id="samuel-deme">
                        <h3>Samuel Deme</h3>
                        <p>judosamodem@gmail.com</p>    
                        <p>0984 895 654</p>
                        </div>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1324.8451025755876!2d20.014136465808562!3d48.38568706681902!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x473ff2d321234ba1%3A0x4266499513fd6727!2sKalmana%20Miksz%C3%A1tha%20269%2F1%2C%20979%2001%20Rimavsk%C3%A1%20Sobota!5e0!3m2!1ssk!2ssk!4v1682419835133!5m2!1ssk!2ssk" id = "mapa" width="400" height="300" style="border:2;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> <br> <br>
                        <a href="index.php" id="back-to-top">Speť na úvodnú stránku</a> <br> <br>
                    </section>
                </div>
            </main>
            <p>&copy; Všetky práva vyhradené Marcel Deme, 2023</p><!--týmto kódom sa na webovej stránke zobrazuje informácia o autorských právach a autore, ktorý má tieto práva, spolu s rokom, v ktorom sú tieto práva platné-->
        </body>
    </html>
</footer>
