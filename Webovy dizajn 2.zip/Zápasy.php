<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Zápasy</title>

</head>
<body>
<?php include "hlavičkapeta/header.php";?> 

 <main>
    <div id="Zápasy">
        <h2>Všetky zápasy</h2>
        <table>
            <thead>
                <tr>
                    <th>Dátum</th>
                    <th>Zápas</th>
                    <th>Výsledok</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>sobota, 25 september 2023</td>
                    <td>RSKET vs. LUČENEC</td>
                    <td>0 : 0</td>
                </tr>
                <tr>
                    <td>nedeľa, 26 september 2023</td>
                    <td>RSKET vs. FIĽAKOVO</td>
                    <td>0 : 0</td>
                </tr>
                <tr>
                    <td>sobota, 9 október 2023</td>
                    <td>RSKET vs. KOŠICE</td>
                    <td>0 : 0</td>
                </tr>
                <tr>
                    <td>sobota, 23 október 2023</td>
                    <td>Spiš.N.Ves vs. RSKET</td>
                    <td>0 : 0</td>
                </tr>
                <tr>
                    <td>sobota, 24 október 2023</td>
                    <td>Nitra vs. RSKET</td>
                    <td>0 : 0</td>
                </tr>
            </tbody>
        </table>
    </div>
</main>

<?php include "hlavičkapeta/footer.php"; ?>
</body>
</html>

