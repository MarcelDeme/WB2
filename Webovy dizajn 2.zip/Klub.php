<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Klub</title>
    
</head>

<body>
    <?php include "hlavičkapeta/header.php";?>

    <main>
        <div id="Klub">
            <section>
                <h3>Prihlásenie</h3>
                        

                <form action="prihlasenie.php" method="POST" novalidate>
                    <label for="pouzivatelske_meno">Používateľské meno</label>
                    <input type="text" name="pouzivatelske_meno" id="pouzivatelske_meno" autofocus> <br>
                    <label for="heslo">Heslo</label>
                    <input type="password" name="heslo" id="heslo"> <br> <br>
                    <input type="submit" name="prihlasit" value="Prihlásiť"> <br>
                </form>
            </section>

            <section>
                <h3>Registrácia</h3>
                <?php if (!empty($registrationErrors)) { ?>
                    <p>Nastala chyba: <?php echo $registrationErrors; ?></p>
                <?php } elseif (isset($registrationSuccess)) { ?>
                    <p><?php echo $registrationSuccess; ?></p>
                <?php } ?>        

               <form action="registracia.php" method="POST" novalidate>
                    <label for="meno">Meno</label>
                    <input type="text" name="meno" id="meno" > <br>
                    <label for="heslo">Heslo</label>
                    <input type="password" name="heslo" id="heslo"> <br>
                    <label for="email">E-mail</label>
                    <input type="email" name="email" id="email"> <br>
                    <label for="sprava">Správa</label>
                    <textarea name="sprava" id="sprava"></textarea> <br> <br>
                    <input type="submit" name="odoslat" value="Registrovať"> <br> <br>
                </form>
            </section>
        </div>
        <?php include "hlavičkapeta/footer.php"; ?>
</body>
</html>





  