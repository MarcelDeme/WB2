<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Tréningy</title>
    
</head>
<body>
    <?php include "hlavičkapeta/header.php";?>
    <main>
    <div id="Zápasy">

        <h2>Tréningový rozvrh</h2>
        <table><!--slúži na vytvorenie tabuľky-->
            <thead><!--hlavička tabuľky-->
                <tr>
                    <th>Dátum</th>
                    <th>Čas</th>
                    <th>Tréner</th>
                </tr>
            </thead>
            <tbody><!--definuje telo tabuľky-->
                <tr>
                    <td>2. máj 2023</td>
                    <td>10:00 - 12:00</td>
                    <td>Samuel Deme</td>
                </tr>
                <tr>
                    <td>4. máj 2023</td>
                    <td>14:00 - 16:00</td>
                    <td>Samuel Deme</td>
                </tr>
                <tr>
                    <td>6. máj 2023</td>
                    <td>18:00 - 20:00</td>
                    <td>Samuel Deme</td>
                </tr>
                <tr>
                    <td>8. máj 2023</td>
                    <td>10:00 - 12:00</td>
                    <td>Samuel Deme</td>
                </tr>
                <tr>
                    <td>10. máj 2023</td>
                    <td>14:00 - 16:00</td>
                    <td>Samuel Deme</td>
                </tr>
                <tr>
                    <td>12. máj 2023</td>
                    <td>18:00 - 20:00</td>
                    <td>Samuel Deme</td>
                <tr>
            </tbody>
        </table>
    </div>
    </main>
    <?php include "hlavičkapeta/footer.php"; ?>
</body>
</html>