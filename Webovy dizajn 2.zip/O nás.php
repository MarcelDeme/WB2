<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>O nás</title>
</head>

<body>
<?php include "hlavičkapeta/header.php";?> 

<div id="Onás">

<h3>
<p>Športový klub RSKET vznikol v roku 2023 na podnet skupiny športových nadšencov, ktorí chceli športovať a organizovať šport pre radosť.</p> <br>

<p>Zakladatelia si dali do vienka niekoľko základných bodov činnosti ako sú napr. výchova a vzdelávanie detí prostredníctvom športu, všestranne rozvíjať športovú činnosť a aktívne využívať fond voľného času, starať sa o rozvoj basketbalu v mieste pôsobenia klubu, hľadať a rozvíjať športové talenty basketbalu, pracovať a podávať výborné výsledky na úrovni výkonnostného basketbalu.</p> <br> 

<p>V súčasnom období má náš Klub stálu organizačnú štruktúru, pripravujeme centrá mládeže, vyhľadávame talentované deti a snažíme sa zlepšovať materiálne vybavenie tréningových priestorov.</p> <br>

<p>Spolupracujeme s basketbalovými klubmi na Slovensku. Okrem spolupráce na klubovej úrovni náš klub veľmi úzko spolupracuje s mestom Rimavská Sobota a jeho mestskými časťami, so ZŠ, s neziskovými organizáciami. Privítame spoluprácu s každým, komu záleží na zdravom rozvoji detí a mládeže ako po fyzickej stránke, tak aj po psychickej stránke</p> <br> 

<p>Dôležitou prioritou klubu pre súčasné obdobie je práca s deťmi a mládežou pre ich rozvoj a zdravie a snaha o zvýšenie úrovne basketbalu na základných školách.</p> <br></h3> 


</div>

<?php include "hlavičkapeta/footer.php"; ?>

</body>
</html>