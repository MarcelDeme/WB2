<?php
// DATABÁZA -- prihlásenie do databázy premenné s údajmi -- premenná connection --  vypis či sme sa úspešne prihlásili -- premenná sql na vypis co chcem aby nám vypísalo -- premenná result do néj budeme chciet výsledky -- mysqli_query dotaz na databázu -- var_dump vypíše result -- mysqli_fetch_all urobi z result pole vyberie všetkých hráčov(zobrazenie na stranke zobraziť zdrojový kód) -- MYSQLI_ASSOC asociativne pole

$db_host = "127.0.0.1";
$db_user = "SamuelDeme";
$db_password = "Samko2006";
$db_name = "rsket";

$connection = mysqli_connect($db_host, $db_user, $db_password, $db_name);

if (mysqli_connect_error()){
    echo mysqli_connect_error();
    exit;
}
$sql = "SELECT * FROM kadet ORDER BY Meno ASC";
$result = mysqli_query($connection, $sql);
$hráči = mysqli_fetch_all($result, MYSQLI_ASSOC);
 
 ?>
<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=he, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Hráči</title>
</head>
<body>
<?php include "hlavičkapeta/header.php";?>
<div id="hráči"> 

<h2>Zoznam hráčov klubu RSKET - kadeti</h2><br><br>



<?php if (empty($hráči)): ?>
    <p>Žiadny hráč nenajdený</p>
<?php else: ?>
    <ul>
    <?php foreach($hráči as $prvý_hráč): ?>
      <li>
           <?php echo $prvý_hráč["Meno"]. " " .$prvý_hráč["Priezvisko"] ?>
      </li>
      <a href="hráči.php?id=<?php echo $prvý_hráč["id"] ?>">Viac informácií</a> <!--dostali sme id do url adresy-->
    <?php endforeach; ?>
    </ul> 
    <?php endif; ?> 
    <?php if ($hráči === null): ?>
        <p> Hráč nenajdený </p>
    <?php else: ?>
        <?php endif ?>
</div>
    

<?php include "hlavičkapeta/footer.php"; ?>
</body>
</html>