<?php
if (isset($_POST["odoslat"])) {
    $servername = "127.0.0.1";
    $username = "root";
    $password = "";
    $database = "prihla";

    // Vytvorenie pripojenia
    $conn = new mysqli($servername, $username, $password, $database);
    //je premenná, do ktorej je priradený vytvorený objekt triedy mysqli. Táto premenná sa používa na volanie metód a operácií spojených s pripojením a manipuláciou s databázou//
    
    // Skontrolovanie pripojenia
    if ($conn->connect_error) {
        die("Chyba pripojenia k databáze: " . $conn->connect_error);
    }

    // Prihlasovacie údaje
    $pouzivatelske_meno = $_POST["pouzivatelske_meno"];
    $heslo = $_POST["heslo"];

    // Escapovanie hodnôt pre bezpečnosť
    $pouzivatelske_meno = $conn->real_escape_string($pouzivatelske_meno);
    $heslo = $conn->real_escape_string($heslo);

    // SQL dotaz pre overenie prihlasovacích údajov
    $sql = "SELECT * FROM users WHERE username = '$pouzivatelske_meno' AND password = '$heslo'";// je SQL dotaz, ktorý vyberá všetky stĺpce (*) z tabuľky users, kde hodnota stĺpca username sa zhoduje s premennou $pouzivatelske_meno a hodnota stĺpca password sa zhoduje s premennou $heslo//
    $result = $conn->query($sql);//vykonáva SQL dotaz na pripojenom objekte $conn a ukladá výsledok do premennej $result. Táto premenná bude obsahovať výsledok dotazu, ktorý môže byť následne spracovaný//

    // Kontrola výsledku
    if ($result->num_rows == 1) {//Podmienka if ($result->num_rows == 1) overuje, či počet riadkov vo výsledku dotazu je rovný 1. Ak áno, znamená to, že v tabuľke users existuje záznam s daným používateľským menom a heslom. V takom prípade sa vykoná kód vo vnútri if bloku//
        // Prihlásenie úspešné
        // Presmerovanie na index.php
        header("Location: index.php");
        exit(); // Ukončenie skriptu
        
    } else {
        // Prihlásenie neúspešné
        echo "Neúspešné prihlásenie";
    }

    // Zatvorenie pripojenia
    $conn->close();
}
?>


