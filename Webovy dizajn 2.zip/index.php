
<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Basketbal Rimavská Sobota</title>
</head>
<body>
  <?php include "hlavičkapeta/header.php";?>
<div id="index">
  <main>
   <section>
    <h1>RSKET</h1>
    <h2>Tréningy basketbalu v Rimavskej Sobote</h2><br>
    
    
   <img src="img/bas1.jpg" alt="Basketbalový obrázok" style="width: 50%;">
   <img src="img/baskos.jpg" alt="Basketbalový obrázok" style="width: 50%;">
   <img src="img/bas.jpg" alt="Basketbalový obrázok" style="width: 50%;">
   
  
      
   </section>
    
    <h3>Basketbalový klub od 1.ročníka ZŠ a starších</h3><br>
    <h3>Nastal správny čas aby sme posunuli absentujúcu tréningovú úroveň basketbalu v Rimavskej Sobote</h3>

    <p>rsbasketbal@gmail.com</p><br>
    <h3> Staň sa súčasťou nášho baketbalového klubu</h3><br>
    
    <h3>„Ak sa snažíte niečo dosiahnuť, narazíte na prekážky. Rovnako ako každý, aj ja som sa s nimi stretol. Ale prekážky vás nemusia zastaviť. Ak narazíte na stenu, neotáčajte sa a nevzdávajte sa. Vymyslite, ako ju prekonať, prejsť cez ňu alebo ju obísť.“ — Michael Jordan</h3>

  </main> 
</div>
 <?php include "hlavičkapeta/footer.php"; ?>
 <!--tieto kódy v PHP slúžia na vloženie obsahu z iných súborov do aktuálneho súboru, uľahčujú opakovanie a znovupoužiteľnosť kódu, keďže hlavička a pätička sú spoločné pre viacero stránok-->
</body>
</html>