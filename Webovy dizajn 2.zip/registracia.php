<?php
if (isset($_POST["odoslat"])) {//kontroluje,či bol odoslaný formulár s názvom "odoslat"//
    $mysqli = new mysqli("127.0.0.1", "root", "", "regist");//vytvára pripojenie k databáze MySQL//

    $meno = $_POST["meno"];//získavajú hodnoty z polí formulára a ukladajú ich do premenných// 
    $heslo = $_POST["heslo"];
    $email = $_POST["email"];

    $registrationErrors = "";//slúžia na uchovávanie chýb alebo úspešnej správy registrácie, ktoré sa budú zobraziť používateľovi neskôr//
    $registrationSuccess = "";

    // Overenie vyplnenia všetkých polí
    if (empty($meno) || empty($heslo) || empty($email)) {
        $registrationErrors .= "Musíte vyplniť všetky polia.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registrationErrors .= "Zadaný e-mail je nesprávny.";
    } else {
        // Otvorenie spojenia s databázou
        $mysqli = new mysqli("127.0.0.1", "root", "", "regist");
        if ($mysqli->connect_errno) {
            echo "Nastala chyba pri pripájaní k databáze: " . $mysqli->connect_error;
            exit();
        }

        // Escapovanie hodnôt,Takže tento kód zabezpečuje, že hodnoty premenných $meno, $heslo a $email budú vhodne escapované, aby sa predišlo možným bezpečnostným problémom spojeným s SQL injekciou//
        $meno = $mysqli->real_escape_string($meno);
        $heslo = $mysqli->real_escape_string($heslo);
        $email = $mysqli->real_escape_string($email);

        // Kontrola existencie užívateľa
        $vysledok = $mysqli->query("SELECT * FROM user WHERE username='{$meno}'");
        if ($vysledok->num_rows) {
            $registrationErrors .= "Užívateľ so zadaným menom už existuje";
            $vysledok->free();
        }

        // Vloženie nového užívateľa do databázy
        if (empty($registrationErrors)) {
            $hashedHeslo = password_hash($heslo, PASSWORD_DEFAULT);
            //Táto funkcia slúži na zahashovanie hesla používateľa. Heslo sa hashuje, čo znamená, že sa transformuje na nečitateľný reťazec znakov s použitím šifrovacej funkcie//
            $vlozenie = $mysqli->query("INSERT INTO `user` (username, password, email) VALUES ('{$meno}', '{$hashedHeslo}', '{$email}')");
            if ($vlozenie) {
                $registrationSuccess = "Uživateľ {$meno} bol úspešne zaregistrovaný.";
                header("Location: index.php"); // Presmerovanie na index.php
                exit(); // Ukončenie skriptu po presmerovaní
            } else {
                echo "Nastala chyba pri registrácii.";
            }
        }
        // Uzatvorenie spojenia s databázou
        $mysqli->close();
    }
}
?>

<?php
if (!empty($registrationErrors)) {
    echo "Nastala chyba: " . $registrationErrors;
}

if (!empty($registrationSuccess)) {
    echo $registrationSuccess;
}
//Po odoslaní formulára sa najskôr vytvára spojenie s databázou, pričom sa používajú údaje ako IP adresa (127.0.0.1), meno používateľa ("root"), prázdne heslo a názov databázy ("regist"). Potom sa získavajú hodnoty z $_POST premenných pre meno, heslo a email.
//Následne sa kontroluje vyplnenie všetkých polí a správnosť zadaného emailu. Ak sú všetky údaje správne vyplnené, otvára sa spojenie s databázou, kde sa kontroluje existencia užívateľa s rovnakým menom. Ak užívateľ neexistuje, vkladá sa nový záznam o užívateľovi do databázy s hashovaným heslom.
//Ak pri registrácii nastala chyba, vypisuje sa príslušné hlásenie. Ak registrácia prebehla úspešne, vypisuje sa oznámenie o úspešnej registrácii.
?>


