<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <?php
        $cas = date('G');//premenná $cas je inicializovaná s hodinou aktuálneho času pomocou funkcie date('G')//
        if ($cas < 9) {
            echo "<p>Dobré ráno, vítam ťa na našej stránke</p>";
        } elseif ($cas < 12) {
            echo "<p>Dobré dopoludnie, vítam ťa na našej stránke</p>";
        } elseif ($cas < 18) {
            echo "<p>Dobré popoludnie, vítam ťa na našej stránke</p>";
        } else {
            echo "<p>Dobrý večer, vítam ťa na našej stránke</p>";
        }
        ?><!--týmto kódom sa dosahuje dynamické zobrazovanie pozdravu v závislosti od aktuálneho času na webovej stránke-->
        <div class="header"> 
        <div class="logo">
            <img src="img/logo.png.png" alt="Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Úvod</a></li>
                <li><a href="O nás.php">O nás</a></li>
                <li><a href="Tréneri.php">Tréneri</a></li>
                <li><a href="Hráči.php">Hráči</a></li>
                <li><a href="Zápasy.php">Zápasy</a></li>
                <li><a href="Tréningy.php">Tréningy</a></li>
                <li><a href="Klub.php">Klub</a></li>
            </ul>
        </nav>
        
        </div>
        <div id="cas">
            <h3>Aktuálny čas</h3>
            <span><?php echo date('H:i:s'); ?></span>
            <script>
                setInterval(function() {
                    var currentTime = new Date();
                    document.querySelector('#cas span').innerHTML = currentTime.getHours() + ':' + currentTime.getMinutes() + ':' + currentTime.getSeconds();
                }, 1000);
            </script>
        </div>
        <!-- JavaScript je použitá funkcia setInterval(), ktorá slúži na opakované spúšťanie funkcie s určitým časovým intervalom. V tomto prípade je interval nastavený na 1000 milisekúnd (1 sekunda), Funkcia, ktorá sa opakovane spúšťa, získa aktuálny čas pomocou objektu Date() a nastaví tento čas do vnútra span elementu vo vnútri div s identifikátorom "cas". -->
    </header>
</body>
</html>

